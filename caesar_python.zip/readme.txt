This program encrypts your text using the Caesar method. Each letter is shifted by a value in the alphabet. You can specify the rotation value at the beginning of my program.

Music by Eric Matyas